import { createHmac } from 'node:crypto';

// Zoom webhook is currently DISABLED
Deno.serve(async (req) => {
  try {
    const bodyText = await req.text();
    let body;
    try { body = JSON.parse(bodyText); } catch { return Response.json({ received: true }); }

    // Still handle URL validation so Zoom doesn't error out
    if (body.event === "endpoint.url_validation") {
      const secret = Deno.env.get("ZOOM_WEBHOOK_SECRET");
      if (!secret) return Response.json({ error: "Webhook secret not configured" }, { status: 500 });
      const plainToken = body.payload?.plainToken;
      if (!plainToken) return Response.json({ error: "No plainToken" }, { status: 400 });
      const hash = createHmac("sha256", secret).update(plainToken).digest("hex");
      return Response.json({ plainToken, encryptedToken: hash });
    }

    // All other events: disabled, do nothing
    console.log("Zoom webhook disabled — ignoring event:", body.event);
    return Response.json({ received: true, status: "disabled" });
  } catch (error) {
    return Response.json({ received: true });
  }
});