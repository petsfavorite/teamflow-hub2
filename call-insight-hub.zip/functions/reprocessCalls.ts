import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';
import OpenAI from 'npm:openai';

const openai = new OpenAI({ apiKey: Deno.env.get("OPENAI_API_KEY") });

async function getZoomToken() {
  const accountId = Deno.env.get("ZOOM_ACCOUNT_ID");
  const clientId = Deno.env.get("ZOOM_CLIENT_ID");
  const clientSecret = Deno.env.get("ZOOM_CLIENT_SECRET");

  const credentials = btoa(`${clientId}:${clientSecret}`);

  const res = await fetch(
    `https://zoom.us/oauth/token?grant_type=account_credentials&account_id=${accountId}`,
    { method: "POST", headers: { Authorization: `Basic ${credentials}` } }
  );
  const data = await res.json();
  
  if (!res.ok) {
    throw new Error(`Failed to get Zoom token: ${data.reason || data.message}`);
  }
  
  return data.access_token;
}

async function getCallHistoryDetail(callLogId, token) {
  const res = await fetch(`https://api.zoom.us/v2/phone/call_history_detail/${callLogId}`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  if (!res.ok) return null;
  return await res.json();
}

async function getRecordingDownloadUrl(call, token) {
  try {
    if (call.recording_status !== "recorded") return null;
    
    // Get user ID from callee (the person who answered)
    // For this, we need to look up the user from callee_ext_id or try to find them
    // For now, we'll construct the expected URL format
    // The actual download requires /users/{userId}/recordings endpoint
    
    // As a fallback, try constructing a direct recording download URL
    if (call.call_path_id) {
      const downloadUrl = `https://api.zoom.us/v2/recordings/${call.call_path_id}/download?access_token=${token}`;
      console.log("Attempting recording download with call_path_id:", call.call_path_id);
      return downloadUrl;
    }
    
    return null;
  } catch (err) {
    console.error("Error constructing recording download URL:", err);
    return null;
  }
}

async function transcribeRecording(downloadUrl, token) {
  if (!downloadUrl) return null;
  
  try {
    console.log("Downloading recording from:", downloadUrl.slice(0, 80) + "...");
    const audioRes = await fetch(downloadUrl, {
      headers: { Authorization: `Bearer ${token}` }
    });
    console.log("Audio download response status:", audioRes.status);
    if (!audioRes.ok) {
      const errText = await audioRes.text();
      console.error("Audio download failed:", errText.slice(0, 200));
      return null;
    }
    
    const arrayBuffer = await audioRes.arrayBuffer();
    console.log("Downloaded audio size:", arrayBuffer.byteLength, "bytes");
    const buffer = new Uint8Array(arrayBuffer);
    const blob = new Blob([buffer], { type: 'audio/mp4' });
    const file = new File([blob], 'recording.mp4', { type: 'audio/mp4' });
    
    console.log("Starting transcription with OpenAI...");
    const transcript = await openai.audio.transcriptions.create({
      file: file,
      model: 'whisper-1',
      language: 'en'
    });
    
    console.log("Transcription completed:", transcript.text.slice(0, 100) + "...");
    return transcript.text;
  } catch (err) {
    console.error("Transcription error:", err.message);
    return null;
  }
}

function fuzzyMatchStaff(detectedName, staffList) {
  if (!detectedName || !staffList.length) return detectedName;
  const lower = detectedName.toLowerCase();
  
  const exact = staffList.find(s => s.name.toLowerCase() === lower);
  if (exact) return exact.name;
  
  const nickMatch = staffList.find(s =>
    s.nicknames?.some(nick => nick.toLowerCase() === lower)
  );
  if (nickMatch) return nickMatch.name;
  
  const partial = staffList.find(s => {
    const sLower = s.name.toLowerCase();
    const firstName = sLower.split(" ")[0];
    const nicknames = (s.nicknames || []).map(n => n.toLowerCase());
    return sLower.includes(lower) || lower.includes(firstName) ||
           nicknames.some(n => n.includes(lower) || lower.includes(n));
  });
  if (partial) return partial.name;
  
  let best = null, bestScore = 0;
  for (const s of staffList) {
    const sLower = s.name.toLowerCase();
    let matches = 0;
    for (const ch of lower) if (sLower.includes(ch)) matches++;
    const score = matches / Math.max(lower.length, sLower.length);
    if (score > bestScore) { bestScore = score; best = s.name; }
  }
  return bestScore > 0.4 ? best : detectedName;
}

async function analyzeCall(transcript, callerInfo, staffList) {
  if (!transcript && !callerInfo) return {};

  const staffNames = staffList.map(s => s.name).join(", ");
  const staffOptions = staffList.map(s => `"${s.name}"`).join(" | ");
  
  const prompt = `You are an AI analyzing a phone call for a veterinary clinic / pet boarding / doggie day care facility.

${transcript ? `TRANSCRIPT:\n${transcript}\n` : "(No transcript available)"}
CALLER INFO: ${JSON.stringify(callerInfo)}

${staffNames ? `KNOWN STAFF MEMBERS: ${staffNames}
IMPORTANT: For the answered_by field, you MUST pick the EXACT name from this list: ${staffOptions}. If no exact match and you must pick, choose the closest one. If truly no name detected, return null.` : ""}

Analyze this call and return a JSON object with these exact fields:
- answered_by: string or null (MUST be one of: ${staffOptions} if available, or null if not determinable)
- caller_name: string (caller's name if mentioned, else null)
- caller_type: "potential_client" | "returning_client" | "not_applicable"
- caller_intent: string (brief 1-sentence description of what the caller wanted)
- bookable: "yes" | "no" | "unclear"
- booking_outcome: "appt_booked" | "appt_not_booked" | "appt_not_needed"
- booked_date: string in YYYY-MM-DD format if appt_booked, else null
- sentiment: "positive" | "neutral" | "negative"
- transcript_summary: string (2-3 sentence summary)
- ai_notes: string (any important flags or notes)

Return ONLY valid JSON, no markdown.`;

  const response = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [{ role: "user", content: prompt }],
    response_format: { type: "json_object" }
  });

  return JSON.parse(response.choices[0].message.content);
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (user?.role !== 'super_admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const zoomToken = await getZoomToken();

    // Fetch last 10 calls (no time filter)
    const listRes = await fetch(`https://api.zoom.us/v2/phone/call_history?page_size=10`, {
      headers: { Authorization: `Bearer ${zoomToken}` }
    });
    
    const listData = await listRes.json();
    console.log("Zoom API response (first call):", JSON.stringify(listData.call_logs?.[0] || listData.call_histories?.[0], null, 2));
    
    if (!listRes.ok) {
      throw new Error(`Failed to fetch call history: ${listData.message || listRes.statusText}`);
    }
    
    const calls = listData.call_logs || listData.call_histories || [];
    
    if (calls.length === 0) {
      return Response.json({ success: true, processed: 0, total: 0, message: "No calls found in Zoom account" });
    }

    const staffList = await base44.asServiceRole.entities.StaffMember.filter({ is_active: true });

    let processed = 0;
    for (const call of calls) {
      try {
        const callId = call.id;
        console.log(`\n--- Processing call ${callId} ---`);
        console.log("Call object keys:", Object.keys(call));
        console.log("Recording status:", call.recording_status);
        console.log("Call path ID:", call.call_path_id);
        
        const callDetail = await getCallHistoryDetail(callId, zoomToken);
        console.log("Call detail keys:", callDetail ? Object.keys(callDetail) : "null");
        if (callDetail) console.log("Call detail recording_status:", callDetail.recording_status);
        
        let transcript = null;
        // Note: Zoom Phone API doesn't provide direct download URLs
        // Recordings are only accessible via webhooks (phone.recording_completed event)
        if (call.recording_status === "recorded") {
          console.log("Recording available, but requires webhook for download URL");
        }

        const direction = call.direction || callDetail?.direction || "inbound";
        const callerInfo = {
          caller_number: call.caller?.phone_number || call.caller_did_number,
          callee_number: call.callee?.phone_number || call.callee_did_number,
          duration: call.duration,
          direction,
          call_path: callDetail ? JSON.stringify(callDetail).slice(0, 2000) : null
        };

        const analysis = await analyzeCall(transcript, callerInfo, staffList);
        if (analysis.answered_by && staffList.length) {
          analysis.answered_by = fuzzyMatchStaff(analysis.answered_by, staffList);
        }

        let recordingUrl = null;
        if (!recordingUrl && downloadUrl) {
          recordingUrl = downloadUrl;
        }

        const recordData = {
          zoom_meeting_id: callId,
          call_date: call.end_time || new Date().toISOString(),
          call_duration_seconds: call.duration,
          caller_phone: call.caller?.phone_number || call.caller_did_number,
          call_direction: direction,
          transcript: transcript,
          recording_url: recordingUrl,
          status: "pending_review",
          was_booked: analysis.booking_outcome === "appt_booked",
          bookable: analysis.bookable,
          ...analysis
        };

        await base44.asServiceRole.entities.CallRecord.create(recordData);
        processed++;
      } catch (err) {
        console.error(`Failed to process call:`, err);
      }
    }

    return Response.json({ success: true, processed, total: calls.length });
  } catch (error) {
    console.error("Reprocess error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});