import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';
import OpenAI from 'npm:openai';
import { createHmac } from 'node:crypto';

const openai = new OpenAI({ apiKey: Deno.env.get("OPENAI_API_KEY") });

async function getZoomToken() {
  const accountId = Deno.env.get("ZOOM_ACCOUNT_ID");
  const clientId = Deno.env.get("ZOOM_CLIENT_ID");
  const clientSecret = Deno.env.get("ZOOM_CLIENT_SECRET");
  const credentials = btoa(`${clientId}:${clientSecret}`);

  const res = await fetch(
    `https://zoom.us/oauth/token?grant_type=account_credentials&account_id=${accountId}`,
    { method: "POST", headers: { Authorization: `Basic ${credentials}` } }
  );
  const data = await res.json();
  if (!data.access_token) throw new Error("Failed to get Zoom token: " + JSON.stringify(data));
  return data.access_token;
}

async function getRecentCallLogs(token, pageSize = 5) {
  const res = await fetch(
    `https://api.zoom.us/v2/phone/call_logs?type=all&page_size=${pageSize}`,
    { headers: { Authorization: `Bearer ${token}` } }
  );
  const data = await res.json();
  console.log("Call logs response:", JSON.stringify(data).slice(0, 1000));
  return data.call_logs || [];
}

async function getZoomTranscript(recordingId, token) {
  const res = await fetch(`https://api.zoom.us/v2/phone/recordings/${recordingId}/transcript`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  if (!res.ok) return null;
  const data = await res.json();
  if (Array.isArray(data?.transcript)) {
    return data.transcript.map(seg => `${seg.user_name || "Unknown"}: ${seg.text}`).join("\n");
  }
  return data?.transcript || null;
}

async function analyzeCall(transcript, callerInfo, staffList) {
  const staffNames = staffList.map(s => s.name).join(", ");
  const prompt = `You are an AI analyzing a phone call for a veterinary clinic / pet boarding / doggie day care facility.

${transcript ? `TRANSCRIPT:\n${transcript}\n` : "(No transcript available)"}
CALLER INFO: ${JSON.stringify(callerInfo)}
${staffNames ? `KNOWN STAFF MEMBERS: ${staffNames}` : ""}

Analyze this call and return a JSON object with these exact fields:
- answered_by: string or null
- caller_name: string or null
- caller_type: "potential_client" | "returning_client" | "not_applicable"
- caller_intent: string
- bookable: "yes" | "no" | "unclear"
- was_booked: boolean
- booked_date: string YYYY-MM-DD or null
- sentiment: "positive" | "neutral" | "negative"
- transcript_summary: string
- ai_notes: string

Return ONLY valid JSON, no markdown.`;

  const response = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [{ role: "user", content: prompt }],
    response_format: { type: "json_object" }
  });

  return JSON.parse(response.choices[0].message.content);
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const zoomToken = await getZoomToken();
    const callLogs = await getRecentCallLogs(zoomToken, 5);

    if (!callLogs.length) {
      return Response.json({ message: "No call logs found", imported: 0 });
    }

    const staffList = await base44.asServiceRole.entities.StaffMember.filter({ is_active: true });

    let imported = 0;
    let skipped = 0;
    const results = [];

    for (const call of callLogs) {
      const callId = call.id;

      // Skip if already exists
      const existing = await base44.asServiceRole.entities.CallRecord.filter({ zoom_meeting_id: callId });
      if (existing?.length) {
        skipped++;
        results.push({ id: callId, status: "skipped (already exists)" });
        continue;
      }

      // Try to get transcript
      const recordingId = call.recording_id;
      const transcript = recordingId ? await getZoomTranscript(recordingId, zoomToken) : null;

      const callerInfo = {
        caller_number: call.caller_did_number || call.caller?.phone_number,
        callee_number: call.callee_did_number || call.callee?.phone_number,
        duration: call.duration,
        direction: call.direction,
      };

      const analysis = await analyzeCall(transcript, callerInfo, staffList);

      const recordData = {
        zoom_meeting_id: callId,
        call_date: call.date_time || new Date().toISOString(),
        call_duration_seconds: call.duration,
        caller_phone: call.caller_did_number || call.caller?.phone_number,
        call_direction: call.direction || "inbound",
        transcript: transcript,
        status: "pending_review",
        ...analysis
      };

      await base44.asServiceRole.entities.CallRecord.create(recordData);
      imported++;
      results.push({ id: callId, status: "imported", direction: call.direction, date: call.date_time });
    }

    return Response.json({ imported, skipped, results });
  } catch (error) {
    console.error("Import error:", error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});