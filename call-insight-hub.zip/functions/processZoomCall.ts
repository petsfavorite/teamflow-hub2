import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';
import OpenAI from 'npm:openai';

const openai = new OpenAI({ apiKey: Deno.env.get("OPENAI_API_KEY") });

async function getZoomToken() {
  const accountId = Deno.env.get("ZOOM_ACCOUNT_ID");
  const clientId = Deno.env.get("ZOOM_CLIENT_ID");
  const clientSecret = Deno.env.get("ZOOM_CLIENT_SECRET");
  const credentials = btoa(`${clientId}:${clientSecret}`);

  const res = await fetch(
    `https://zoom.us/oauth/token?grant_type=account_credentials&account_id=${accountId}`,
    { method: "POST", headers: { Authorization: `Basic ${credentials}` } }
  );
  const data = await res.json();
  return data.access_token;
}

async function getCallHistoryDetail(callLogId, token) {
  const res = await fetch(`https://api.zoom.us/v2/phone/call_history_detail/${callLogId}`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  if (!res.ok) return null;
  return await res.json();
}

function fuzzyMatchStaff(detectedName, staffList) {
  if (!detectedName || !staffList.length) return detectedName;
  const lower = detectedName.toLowerCase();
  
  const exact = staffList.find(s => s.name.toLowerCase() === lower);
  if (exact) return exact.name;
  
  const nickMatch = staffList.find(s =>
    s.nicknames?.some(nick => nick.toLowerCase() === lower)
  );
  if (nickMatch) return nickMatch.name;
  
  const partial = staffList.find(s => {
    const sLower = s.name.toLowerCase();
    const firstName = sLower.split(" ")[0];
    const nicknames = (s.nicknames || []).map(n => n.toLowerCase());
    return sLower.includes(lower) || lower.includes(firstName) ||
           nicknames.some(n => n.includes(lower) || lower.includes(n));
  });
  if (partial) return partial.name;
  
  let best = null, bestScore = 0;
  for (const s of staffList) {
    const sLower = s.name.toLowerCase();
    let matches = 0;
    for (const ch of lower) if (sLower.includes(ch)) matches++;
    const score = matches / Math.max(lower.length, sLower.length);
    if (score > bestScore) { bestScore = score; best = s.name; }
  }
  return bestScore > 0.4 ? best : detectedName;
}

async function analyzeCall(transcript, callerInfo, staffList) {
  if (!transcript && !callerInfo) return {};

  const teamNames = staffList.map(s => s.name).join(", ");
  const teamOptions = staffList.map(s => `"${s.name}"`).join(" | ");
  
  const prompt = `You are an AI analyzing a phone call for a veterinary clinic / pet boarding / doggie day care facility.

NOTE: The transcript below was transcribed from the recording using OpenAI Whisper. Just analyze it.

${transcript ? `TRANSCRIPT:\n${transcript}\n` : "(No transcript available)"}
CALLER INFO: ${JSON.stringify(callerInfo)}

${teamNames ? `KNOWN TEAM MEMBERS: ${teamNames}
IMPORTANT: Return the name of the team member as detected in the transcript, even if it doesn't exactly match the list. We will match it against team member names and nicknames afterwards to find the closest match. If truly no name detected, return null.` : ""}

Analyze this call and return a JSON object with these exact fields:
- team_member: string or null (the name of the team member as detected from the transcript, even if not an exact match to the team member list — we will match it against nicknames and pick the closest name afterwards)
- caller_name: string (caller's name if mentioned, else null)
- caller_type: "potential_client" | "returning_client" | "not_applicable"
- caller_intent: string (brief 1-sentence description of what the caller wanted)
- bookable: "yes" | "no" | "unclear"
- booking_outcome: "appt_booked" | "appt_not_booked" | "appt_not_needed"
  IMPORTANT: Use "appt_not_needed" if the caller left a voicemail and no team member actually spoke with them, OR if the caller is confirming an existing appointment. "appt_not_booked" should ONLY be used when we actually spoke to the caller and failed to book a NEW appointment. A voicemail is NOT a missed booking. Confirmations of existing appointments are NOT bookings.
- booked_date: string in YYYY-MM-DDTHH:MM:00 format (24hr) if appt_booked — extract the exact date AND time mentioned in the transcript (e.g. "Tuesday the 4th at 2pm" → use the call's year/month context to resolve the full date). If only a date is mentioned with no time, use YYYY-MM-DD. If no appointment booked, return null.
- transcript_summary: string (2-3 sentence plain-language summary of the call)
- ai_notes: string (any important flags, follow-up needed, missed opportunities, etc. Keep brief.)

Return ONLY valid JSON, no markdown.`;

  const response = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [{ role: "user", content: prompt }],
    response_format: { type: "json_object" }
  });

  return JSON.parse(response.choices[0].message.content);
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    // Override with service token for webhook context
    const serviceBase44 = createClientFromRequest(req, { serviceToken: Deno.env.get('BASE44_SERVICE_TOKEN') });
    const { recordingData, transcript, recordingUrl } = await req.json();

    const recordingId = recordingData.id || recordingData.recording_id;
    const callId = recordingData.call_id || recordingData.call_log_id;

    if (!recordingId) {
      return Response.json({ error: "Missing recording_id" }, { status: 400 });
    }

    // Check if already exists
    const existing = await serviceBase44.asServiceRole.entities.CallRecord.filter({ zoom_meeting_id: callId });
    const existingRecord = existing?.[0];

    const zoomToken = await getZoomToken();
    const callDetail = await getCallHistoryDetail(callId, zoomToken);

    const teamList = await serviceBase44.asServiceRole.entities.TeamMember.filter({ is_active: true });

    const direction = recordingData.direction || callDetail?.direction || "inbound";
    const callerInfo = {
      caller_number: recordingData.caller_number || recordingData.caller?.phone_number,
      callee_number: recordingData.callee_number || recordingData.callee?.phone_number,
      duration: recordingData.duration,
      direction,
      call_path: callDetail ? JSON.stringify(callDetail).slice(0, 2000) : null
    };
    const analysis = await analyzeCall(transcript, callerInfo, teamList);
    
    if (teamList.length && analysis.team_member) {
      analysis.team_member = fuzzyMatchStaff(analysis.team_member, teamList);
    }

    const recordData = {
      zoom_meeting_id: callId,
      call_date: recordingData.date_time || new Date().toISOString(),
      call_duration_seconds: recordingData.duration,
      caller_phone: recordingData.caller_number || recordingData.caller?.phone_number,
      call_direction: direction,
      transcript: transcript,
      recording_url: recordingUrl,
      status: "pending_review",
      was_booked: analysis.booking_outcome === "appt_booked",
      bookable: analysis.bookable,
      ...analysis
    };

    if (existingRecord) {
      await serviceBase44.asServiceRole.entities.CallRecord.update(existingRecord.id, recordData);
    } else {
      await serviceBase44.asServiceRole.entities.CallRecord.create(recordData);
    }

    return Response.json({ success: true });
  } catch (error) {
    console.error("Process call error:", error?.message);
    console.error("Stack trace:", error?.stack);
    return Response.json({ error: error?.message }, { status: 500 });
  }
});