import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';
import OpenAI from 'npm:openai';

const openai = new OpenAI({ apiKey: Deno.env.get("OPENAI_API_KEY") });

async function analyzeTranscript(transcript, callerInfo, staffList) {
  if (!transcript) return {};

  const teamEntries = staffList.map(s => {
    const nicks = (s.nicknames || []).join(", ");
    return `"${s.name}"${nicks ? ` (also known as: ${nicks})` : ""}`;
  }).join("\n");
  const teamOptions = staffList.map(s => `"${s.name}"`).join(" | ");

  const prompt = `You are an AI analyzing a phone call transcript for a veterinary clinic / pet boarding / doggie daycare facility.

TRANSCRIPT:
${transcript}

CALLER INFO: ${JSON.stringify(callerInfo)}

${teamEntries ? `KNOWN TEAM MEMBERS (with nicknames):
${teamEntries}

IMPORTANT: Read the full transcript carefully. Identify which team member was on the call by matching names or nicknames spoken in the transcript. Return the detected name as found in the transcript, even if it's not an exact match to the team member list (we will match it against nicknames and pick the closest name afterwards). If truly no name detected, return null.` : ""}

Analyze this call and return a JSON object with these exact fields:

- team_member: string or null — the name of the team member who was on the call (as detected from the transcript, even if not an exact match to the team member list)
- caller_name: string or null — the non-team-member caller's name if mentioned
- caller_phone: string or null — caller's phone number if mentioned
- caller_type: one of:
    "potential_client" — someone calling who is not yet a client and may want services
    "returning_client" — an existing client calling about their pet(s)
    "not_applicable" — a salesperson, another clinic calling for records, a robocall, or any non-client call
- caller_intent: string — brief 1-sentence description of why they called
- bookable: "yes" | "no" | "unclear" — whether an appointment could have been made for the caller's issue
- booking_outcome: one of:
    "appt_booked" — an appointment was successfully scheduled
    "appt_not_booked" — an appointment could have been made but was NOT (missed opportunity — we actually spoke to the caller and failed to book)
    "appt_not_needed" — no appointment was necessary OR we never actually spoke to the caller (e.g. voicemail left, refill request, checking on a pet, non-client call, records request, confirmation of existing appointment, etc.)

IMPORTANT: If the caller left a voicemail and no team member actually spoke with them, use "appt_not_needed" — NOT "appt_not_booked". A voicemail is NOT a missed booking opportunity since we never had the chance to book them. Also: confirmations of existing appointments are NOT bookings — use "appt_not_needed".
- booked_date: string in YYYY-MM-DDTHH:MM:00 format (24hr) if appt_booked — extract the exact date AND time mentioned in the transcript (e.g. "Tuesday the 4th at 2pm" → use the call's year/month context to resolve the full date). If only a date is mentioned with no time, use YYYY-MM-DD. If no appointment booked, return null.
- transcript_summary: string — 2-3 sentence plain-language summary of the call
- ai_notes: string — any important flags, follow-up needed, missed booking opportunities, or concerns. Keep brief.

Return ONLY valid JSON, no markdown.`;

  const response = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [{ role: "user", content: prompt }],
    response_format: { type: "json_object" }
  });

  return JSON.parse(response.choices[0].message.content);
}

function fuzzyMatchStaff(detectedName, staffList) {
  if (!detectedName || !staffList.length) return detectedName;
  const lower = detectedName.toLowerCase();
  const exact = staffList.find(s => s.name.toLowerCase() === lower);
  if (exact) return exact.name;
  const nickMatch = staffList.find(s => s.nicknames?.some(nick => nick.toLowerCase() === lower));
  if (nickMatch) return nickMatch.name;
  const partial = staffList.find(s => {
    const sLower = s.name.toLowerCase();
    const firstName = sLower.split(" ")[0];
    const nicknames = (s.nicknames || []).map(n => n.toLowerCase());
    return sLower.includes(lower) || lower.includes(firstName) || nicknames.some(n => n.includes(lower) || lower.includes(n));
  });
  if (partial) return partial.name;
  return detectedName;
}

function extractRecordingUrl(rawLink) {
  if (!rawLink) return null;
  // If it's a JSON object string (Google Drive file metadata)
  if (rawLink.trim().startsWith("{")) {
    try {
      const obj = JSON.parse(rawLink);
      return obj.webViewLink || obj.webContentLink || null;
    } catch {
      return null;
    }
  }
  // If it's already a plain URL
  if (rawLink.startsWith("http")) return rawLink;
  return null;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

    const accessToken = await base44.asServiceRole.connectors.getAccessToken("googlesheets");

    const spreadsheetId = "1JEnAmUuImYmca4wpzFnza8IeQv0v049ND_8nvedjR5M";
    const range = "Sheet1!A1:Z2000";

    const res = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(range)}`,
      { headers: { Authorization: `Bearer ${accessToken}` } }
    );

    if (!res.ok) {
      const err = await res.text();
      return Response.json({ error: err }, { status: res.status });
    }

    const data = await res.json();
    const rows = data.values || [];
    if (rows.length < 2) return Response.json({ imported: 0, skipped: 0 });

    const headers = rows[0];
    const records = rows.slice(1).map((row, idx) => {
      const obj = { __rowIndex: idx + 2 }; // +2 because row 1 is header, idx is 0-based
      headers.forEach((h, i) => { obj[h] = row[i] ?? ""; });
      return obj;
    });

    const staffList = await base44.asServiceRole.entities.TeamMember.filter({ is_active: true });

    let imported = 0;
    let skipped = 0;
    const errors = [];

    for (const row of records) {
      try {
        const callDate = row["Date/Time"] || row["Call Date"];
        const transcript = row["Transcript"] || "";
        const rawLink = row["Link to Recording"] || "";
        const directionRaw = (row["Inbound/Outbound"] || "").toLowerCase();
        const call_direction = directionRaw.includes("out") ? "outbound" : "inbound";

        if (!callDate) { skipped++; continue; }

        // Build a unique ID from the sheet row index (stable, row-based dedup)
        const zoom_meeting_id = `sheet_row_${row.__rowIndex}`;

        // Check for existing record
        const existing = await base44.asServiceRole.entities.CallRecord.filter({ zoom_meeting_id });
        if (existing?.length > 0) { skipped++; continue; }

        // Analyze transcript with AI
        const callerInfo = { call_date: callDate, call_direction };
        const analysis = await analyzeTranscript(transcript, callerInfo, staffList);

        if (staffList.length && analysis.team_member) {
          analysis.team_member = fuzzyMatchStaff(analysis.team_member, staffList);
        }

        const recordingUrl = extractRecordingUrl(rawLink);

        const recordData = {
          zoom_meeting_id,
          call_date: new Date(callDate).toISOString(),
          call_direction,
          transcript: transcript || null,
          recording_url: recordingUrl,
          status: "pending_review",
          was_booked: analysis.booking_outcome === "appt_booked",
          ...analysis,
        };

        await base44.asServiceRole.entities.CallRecord.create(recordData);
        imported++;
      } catch (err) {
        errors.push(err.message);
        skipped++;
      }
    }

    return Response.json({ imported, skipped, errors: errors.slice(0, 5) });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});