import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const accessToken = await base44.asServiceRole.connectors.getAccessToken("googlesheets");

    const spreadsheetId = "1JEnAmUuImYmca4wpzFnza8IeQv0v049ND_8nvedjR5M";
    const range = "Sheet1!A1:Z1000";

    const res = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(range)}`,
      { headers: { Authorization: `Bearer ${accessToken}` } }
    );

    if (!res.ok) {
      const err = await res.text();
      return Response.json({ error: err }, { status: res.status });
    }

    const data = await res.json();
    const rows = data.values || [];
    if (rows.length === 0) return Response.json({ headers: [], rows: [] });

    const headers = rows[0];
    const records = rows.slice(1).map(row => {
      const obj = {};
      headers.forEach((h, i) => { obj[h] = row[i] ?? ""; });
      return obj;
    });

    return Response.json({ headers, rows: records, total: records.length });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});