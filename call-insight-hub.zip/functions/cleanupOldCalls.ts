import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    // Admin-only function
    if (user?.role !== 'admin' && user?.role !== 'super_admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    // Calculate date 6 months ago
    const now = new Date();
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

    // Delete calls older than 6 months
    const cutoffDate = sixMonthsAgo.toISOString();
    
    const oldCalls = await base44.asServiceRole.entities.CallRecord.filter({
      call_date: { $lt: cutoffDate }
    });

    let deleted = 0;
    for (const call of oldCalls) {
      await base44.asServiceRole.entities.CallRecord.delete(call.id);
      deleted++;
    }

    return Response.json({ success: true, deleted, cutoffDate });
  } catch (error) {
    console.error('Cleanup error:', error?.message);
    return Response.json({ error: error?.message }, { status: 500 });
  }
});