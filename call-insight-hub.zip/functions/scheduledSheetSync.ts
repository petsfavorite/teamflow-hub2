import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';
import OpenAI from 'npm:openai';

const openai = new OpenAI({ apiKey: Deno.env.get("OPENAI_API_KEY") });

async function analyzeTranscript(transcript, callerInfo, staffList) {
  if (!transcript) return {};

  const teamEntries = staffList.map(s => {
    const nicks = (s.nicknames || []).join(", ");
    return `"${s.name}"${nicks ? ` (also known as: ${nicks})` : ""}`;
  }).join("\n");

  const prompt = `You are an AI analyzing a phone call transcript for a veterinary clinic / pet boarding / doggie daycare facility.

TRANSCRIPT:
${transcript}

CALLER INFO: ${JSON.stringify(callerInfo)}

${teamEntries ? `KNOWN TEAM MEMBERS (with nicknames):
${teamEntries}

IMPORTANT: Read the full transcript carefully. Identify which team member was on the call by matching names or nicknames spoken in the transcript. The team_member field MUST be one of the exact names from the list above. If no match found, return null.` : ""}

Analyze this call and return a JSON object with these exact fields:

- team_member: string or null — the EXACT name from the team member list above who was on the call
- caller_name: string or null — the non-team-member caller's name if mentioned
- caller_phone: string or null — caller's phone number if mentioned
- caller_type: one of:
    "potential_client" — someone calling who is not yet a client and may want services
    "returning_client" — an existing client calling about their pet(s)
    "not_applicable" — a salesperson, another clinic calling for records, a robocall, or any non-client call
- caller_intent: string — brief 1-sentence description of why they called
- bookable: "yes" | "no" | "unclear" — whether an appointment could have been made for the caller's issue
- booking_outcome: one of:
    "appt_booked" — an appointment was successfully scheduled
    "appt_not_booked" — an appointment could have been made but was NOT (missed opportunity)
    "appt_not_needed" — no appointment was necessary (e.g. refill request, checking on a pet, non-client call, records request, etc.)
- booked_date: string in YYYY-MM-DD format if appt_booked, else null
- transcript_summary: string — 2-3 sentence plain-language summary of the call
- ai_notes: string — any important flags, follow-up needed, missed booking opportunities, or concerns. Keep brief.

Return ONLY valid JSON, no markdown.`;

  const response = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [{ role: "user", content: prompt }],
    response_format: { type: "json_object" }
  });

  return JSON.parse(response.choices[0].message.content);
}

function fuzzyMatchStaff(detectedName, staffList) {
  if (!detectedName || !staffList.length) return detectedName;
  const lower = detectedName.toLowerCase();
  const exact = staffList.find(s => s.name.toLowerCase() === lower);
  if (exact) return exact.name;
  const nickMatch = staffList.find(s => s.nicknames?.some(nick => nick.toLowerCase() === lower));
  if (nickMatch) return nickMatch.name;
  const partial = staffList.find(s => {
    const sLower = s.name.toLowerCase();
    const firstName = sLower.split(" ")[0];
    const nicknames = (s.nicknames || []).map(n => n.toLowerCase());
    return sLower.includes(lower) || lower.includes(firstName) || nicknames.some(n => n.includes(lower) || lower.includes(n));
  });
  if (partial) return partial.name;
  return detectedName;
}

function extractRecordingUrl(rawLink) {
  if (!rawLink) return null;
  if (rawLink.trim().startsWith("{")) {
    try {
      const obj = JSON.parse(rawLink);
      return obj.webViewLink || obj.webContentLink || null;
    } catch {
      return null;
    }
  }
  if (rawLink.startsWith("http")) return rawLink;
  return null;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    const accessToken = await base44.asServiceRole.connectors.getAccessToken("googlesheets");

    const spreadsheetId = "1JEnAmUuImYmca4wpzFnza8IeQv0v049ND_8nvedjR5M";
    const range = "Sheet1!A1:Z2000";

    const res = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(range)}`,
      { headers: { Authorization: `Bearer ${accessToken}` } }
    );

    if (!res.ok) {
      const err = await res.text();
      return Response.json({ error: err }, { status: res.status });
    }

    const data = await res.json();
    const rows = data.values || [];
    if (rows.length < 2) return Response.json({ imported: 0, skipped: 0 });

    const headers = rows[0];
    const records = rows.slice(1).map((row, idx) => {
      const obj = { __rowIndex: idx + 2 }; // +2 because row 1 is header, idx is 0-based
      headers.forEach((h, i) => { obj[h] = row[i] ?? ""; });
      return obj;
    });

    const [staffList, allExistingRecords] = await Promise.all([
      base44.asServiceRole.entities.TeamMember.filter({ is_active: true }),
      base44.asServiceRole.entities.CallRecord.list("-created_date", 2000),
    ]);

    // Build a set of already-imported row IDs for O(1) lookup — no per-row DB queries
    const existingIds = new Set(
      (allExistingRecords || []).map(r => r.zoom_meeting_id).filter(Boolean)
    );

    // Find only NEW rows (not yet imported)
    const newRows = records.filter(row => {
      const zoom_meeting_id = `sheet_row_${row.__rowIndex}`;
      return !existingIds.has(zoom_meeting_id);
    });

    // Cap per-run to avoid timeout — scheduler will catch up on next run
    const MAX_PER_RUN = 15;
    const rowsToProcess = newRows.slice(0, MAX_PER_RUN);

    let imported = 0;
    let skipped = 0;
    const errors = [];

    for (const row of rowsToProcess) {
      try {
        const callDate = row["Date/Time"] || row["Call Date"];
        const transcript = row["Transcript"] || "";
        const rawLink = row["Link to Recording"] || "";
        const directionRaw = (row["Inbound/Outbound"] || "").toLowerCase();
        const call_direction = directionRaw.includes("out") ? "outbound" : "inbound";

        if (!callDate) { skipped++; continue; }

        const zoom_meeting_id = `sheet_row_${row.__rowIndex}`;

        const callerInfo = { call_date: callDate, call_direction };
        const analysis = await analyzeTranscript(transcript, callerInfo, staffList);

        if (analysis.team_member && staffList.length) {
          analysis.team_member = fuzzyMatchStaff(analysis.team_member, staffList);
        }

        const recordingUrl = extractRecordingUrl(rawLink);

        const recordData = {
          zoom_meeting_id,
          call_date: new Date(callDate).toISOString(),
          call_direction,
          transcript: transcript || null,
          recording_url: recordingUrl,
          status: "pending_review",
          was_booked: analysis.booking_outcome === "appt_booked",
          ...analysis,
        };

        await base44.asServiceRole.entities.CallRecord.create(recordData);
        imported++;
      } catch (err) {
        errors.push(err.message);
        skipped++;
      }
    }

    return Response.json({ imported, skipped, remaining: newRows.length - rowsToProcess.length, errors: errors.slice(0, 5) });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});