import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { cn } from "@/lib/utils";
import { Phone, Users, LogOut, Menu, X, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const NAV = [
  { label: "Dashboard", page: "Dashboard", icon: Phone },
  { label: "Team", page: "Team", icon: Users },

  { label: "Fetch Data Now", page: "ReprocessCalls", icon: Phone, requiredRole: "super_admin" },
];

export default function Layout({ children, currentPageName }) {
  const [user, setUser] = useState(null);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const isSuperAdmin = user?.role === "super_admin";
  const isAdmin = user?.role === "admin" || user?.role === "super_admin";

  const handleLogout = () => base44.auth.logout();

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Sidebar — desktop */}
      <aside className="hidden md:flex flex-col w-56 bg-white border-r border-slate-100 fixed inset-y-0 left-0 z-10">
        {/* Logo */}
        <div className="px-5 py-5 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 bg-blue-600 rounded-lg">
              <Phone className="w-4 h-4 text-white" />
            </div>
            <div>
              <p className="text-sm font-bold text-slate-900 leading-tight">Call Intelligence</p>
              <p className="text-xs text-slate-400 leading-tight">Vet Clinic</p>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 py-4 space-y-0.5">
          {NAV.filter(item => !item.requiredRole || user?.role === item.requiredRole || user?.role === "super_admin").map(({ label, page, icon: Icon }) => {
            const active = currentPageName === page;
            return (
              <Link
                key={page}
                to={createPageUrl(page)}
                className={cn(
                  "flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                  active
                    ? "bg-blue-50 text-blue-700"
                    : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
                )}
              >
                <Icon className={cn("w-4 h-4", active ? "text-blue-600" : "text-slate-400")} />
                {label}
              </Link>
            );
          })}
        </nav>

        {/* User footer */}
        {user && (
          <div className="px-3 py-4 border-t border-slate-100">
            <div className="flex items-center gap-2.5 px-3 py-2 mb-1">
              <div className="w-7 h-7 rounded-full bg-blue-100 flex items-center justify-center text-xs font-bold text-blue-700">
                {user.full_name?.charAt(0) || "?"}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium text-slate-800 truncate">{user.full_name}</p>
                <div className="flex items-center gap-1">
                  {isSuperAdmin ? (
                    <Badge className="text-[10px] px-1 py-0 h-4 bg-purple-600 gap-0.5">
                      <Shield className="w-2.5 h-2.5" /> Super Admin
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="text-[10px] px-1 py-0 h-4 text-slate-500">Viewer</Badge>
                  )}
                </div>
              </div>
            </div>
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 w-full px-3 py-2 text-xs text-slate-500 hover:text-red-600 rounded-lg hover:bg-red-50 transition-colors"
            >
              <LogOut className="w-3.5 h-3.5" /> Sign Out
            </button>
          </div>
        )}
      </aside>

      {/* Mobile top bar */}
      <div className="md:hidden fixed top-0 left-0 right-0 z-20 bg-white border-b border-slate-100 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-blue-600 rounded-lg">
            <Phone className="w-4 h-4 text-white" />
          </div>
          <p className="text-sm font-bold text-slate-900">Call Intelligence</p>
        </div>
        <Button variant="ghost" size="icon" onClick={() => setMobileOpen(o => !o)}>
          {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </Button>
      </div>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="md:hidden fixed inset-0 z-10 bg-black/40" onClick={() => setMobileOpen(false)}>
          <div className="bg-white w-56 h-full flex flex-col" onClick={e => e.stopPropagation()}>
            <div className="px-5 py-5 mt-14 border-b border-slate-100" />
            <nav className="flex-1 px-3 py-4 space-y-0.5">
              {NAV.filter(item => !item.requiredRole || user?.role === item.requiredRole || user?.role === "super_admin").map(({ label, page, icon: Icon }) => (
                <Link
                  key={page}
                  to={createPageUrl(page)}
                  onClick={() => setMobileOpen(false)}
                  className={cn(
                    "flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-medium",
                    currentPageName === page ? "bg-blue-50 text-blue-700" : "text-slate-600"
                  )}
                >
                  <Icon className="w-4 h-4" />
                  {label}
                </Link>
              ))}
            </nav>
            {user && (
              <div className="px-3 py-4 border-t border-slate-100">
                <p className="text-xs font-medium text-slate-700 px-3">{user.full_name}</p>
                <button onClick={handleLogout} className="flex items-center gap-2 px-3 py-2 mt-1 text-xs text-slate-500">
                  <LogOut className="w-3.5 h-3.5" /> Sign Out
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Page content */}
      <main className="flex-1 md:ml-56 pt-14 md:pt-0">
        {children}
      </main>
    </div>
  );
}