import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { AlertCircle, CheckCircle, Loader2, FileSpreadsheet } from "lucide-react";

export default function ReprocessCalls() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  const handleImport = async () => {
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const res = await base44.functions.invoke("scheduledSheetSync", {});
      setResult(res.data);
    } catch (err) {
      setError(err.message || "Failed to import from Google Sheet");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-8">
      <div className="max-w-2xl">
        <div className="flex items-center gap-3 mb-2">
          <FileSpreadsheet className="w-6 h-6 text-emerald-600" />
          <h1 className="text-2xl font-bold text-slate-900">Import from Google Sheet</h1>
        </div>
        <p className="text-slate-600 mb-6">Import historical call log data from the connected Google Sheet into the dashboard.</p>

        <Card className="p-6">
          <div className="space-y-4">
            <p className="text-sm text-slate-600">This will:</p>
            <ul className="list-disc list-inside space-y-1 text-sm text-slate-600 ml-2">
              <li>Read all rows from the Google Sheet</li>
              <li>Map call data (date, team member, caller, outcomes) to records</li>
              <li>Skip any records already imported (no duplicates)</li>
              <li>Add new records to your dashboard</li>
            </ul>

            <div className="pt-4">
              <Button
                onClick={handleImport}
                disabled={loading}
                className="bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Importing...
                  </>
                ) : (
                  "Import from Google Sheet"
                )}
              </Button>
            </div>

            {result && (
              <div className="mt-6 p-4 bg-emerald-50 border border-emerald-200 rounded-lg">
                <div className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium text-emerald-900">Import Complete</p>
                    <p className="text-sm text-emerald-700 mt-1">
                      {result.imported} records imported · {result.skipped} skipped (already exist or errors)
                      {result.remaining > 0 && ` · ${result.remaining} still remaining`}
                    </p>
                    {result.errors?.length > 0 && (
                      <p className="text-xs text-amber-700 mt-1">Errors: {result.errors.join("; ")}</p>
                    )}
                  </div>
                </div>
              </div>
            )}

            {error && (
              <div className="mt-6 p-4 bg-red-50 border border-red-200 rounded-lg">
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium text-red-900">Error</p>
                    <p className="text-sm text-red-700 mt-1">{error}</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}