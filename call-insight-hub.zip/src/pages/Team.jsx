import { useState, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter
} from "@/components/ui/dialog";
import { Users, Plus, Pencil, Trash2, Loader2, UserCheck, UserX, X } from "lucide-react";

export default function Team() {
  const queryClient = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ name: "", role: "", nicknames: [], is_active: true });
  const [nicknameInput, setNicknameInput] = useState("");
  const nicknameInputRef = useRef(null);

  const { data: user } = useQuery({
    queryKey: ["me"],
    queryFn: () => base44.auth.me()
  });

  const isAdmin = user?.role === "admin" || user?.role === "super_admin";

  const { data: staff = [], isLoading } = useQuery({
    queryKey: ["staff"],
    queryFn: () => base44.entities.TeamMember.list("name", 100)
  });

  const saveMutation = useMutation({
    mutationFn: (data) => editing
      ? base44.entities.TeamMember.update(editing.id, data)
      : base44.entities.TeamMember.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(["staff"]);
      closeDialog();
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.TeamMember.delete(id),
    onSuccess: () => queryClient.invalidateQueries(["staff"])
  });

  const openNew = () => {
    setEditing(null);
    setForm({ name: "", role: "", nicknames: [], is_active: true });
    setNicknameInput("");
    setDialogOpen(true);
  };

  const openEdit = (member) => {
    setEditing(member);
    setForm({
      name: member.name,
      role: member.role || "",
      nicknames: member.nicknames || [],
      is_active: member.is_active !== false
    });
    setNicknameInput("");
    setDialogOpen(true);
  };

  const addNickname = () => {
    const val = nicknameInput.trim();
    if (val && !form.nicknames.includes(val)) {
      setForm(f => ({ ...f, nicknames: [...f.nicknames, val] }));
    }
    setNicknameInput("");
    nicknameInputRef.current?.focus();
  };

  const removeNickname = (nick) => {
    setForm(f => ({ ...f, nicknames: f.nicknames.filter(n => n !== nick) }));
  };

  const closeDialog = () => {
    setDialogOpen(false);
    setEditing(null);
  };

  const handleSave = () => {
    saveMutation.mutate(form);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="bg-white border-b border-slate-100">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6 sm:py-8 flex items-center justify-between">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
              <Users className="w-7 h-7 text-blue-500" />
              Team
            </h1>
            <p className="text-sm text-slate-500 mt-1">{staff.length} team member{staff.length !== 1 ? "s" : ""}</p>
          </div>
          {isAdmin && (
            <Button onClick={openNew} className="bg-blue-600 hover:bg-blue-700 gap-2">
              <Plus className="w-4 h-4" /> Add Member
            </Button>
          )}
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6">
        {staff.length === 0 ? (
          <div className="bg-white rounded-xl border border-dashed border-slate-200 p-12 text-center">
            <Users className="w-8 h-8 text-slate-300 mx-auto mb-3" />
            <p className="text-sm text-slate-500">No team members added yet</p>
            {isAdmin && (
              <Button onClick={openNew} variant="outline" className="mt-4 gap-2">
                <Plus className="w-4 h-4" /> Add First Team Member
              </Button>
            )}
          </div>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2">
            {staff.map(member => (
              <Card key={member.id} className="border-0 shadow-sm p-4 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 font-bold text-sm">
                    {member.name.split(" ").map(n => n[0]).join("").slice(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <p className="font-semibold text-slate-800">{member.name}</p>
                    {member.role && <p className="text-xs text-slate-500">{member.role}</p>}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {member.is_active !== false ? (
                    <Badge variant="outline" className="bg-emerald-50 text-emerald-700 border-emerald-200 text-xs gap-1">
                      <UserCheck className="w-3 h-3" /> Active
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="bg-slate-50 text-slate-500 border-slate-200 text-xs gap-1">
                      <UserX className="w-3 h-3" /> Inactive
                    </Badge>
                  )}
                  {isAdmin && (
                    <>
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(member)}>
                        <Pencil className="w-3.5 h-3.5 text-slate-400" />
                      </Button>
                      <Button
                        variant="ghost" size="icon" className="h-8 w-8"
                        onClick={() => deleteMutation.mutate(member.id)}
                      >
                        <Trash2 className="w-3.5 h-3.5 text-red-400" />
                      </Button>
                    </>
                  )}
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>

      <Dialog open={dialogOpen} onOpenChange={closeDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit Team Member" : "Add Team Member"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label>Full Name *</Label>
              <Input
                placeholder="e.g. Jessica Smith"
                value={form.name}
                onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Role / Title</Label>
              <Input
                placeholder="e.g. Receptionist, Vet Tech"
                value={form.role}
                onChange={e => setForm(f => ({ ...f, role: e.target.value }))}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Nicknames / Variations</Label>
              <div className="flex gap-2">
                <Input
                  ref={nicknameInputRef}
                  placeholder="e.g. Jess, JSmith…"
                  value={nicknameInput}
                  onChange={e => setNicknameInput(e.target.value)}
                  onKeyDown={e => { if (e.key === "Enter") { e.preventDefault(); addNickname(); } }}
                />
                <Button type="button" variant="outline" onClick={addNickname} disabled={!nicknameInput.trim()}>
                  Add
                </Button>
              </div>
              {form.nicknames.length > 0 && (
                <div className="flex flex-wrap gap-1.5 mt-2">
                  {form.nicknames.map(nick => (
                    <span key={nick} className="inline-flex items-center gap-1 bg-blue-50 text-blue-700 text-xs font-medium px-2 py-0.5 rounded-full border border-blue-200">
                      {nick}
                      <button type="button" onClick={() => removeNickname(nick)} className="hover:text-blue-900">
                        <X className="w-3 h-3" />
                      </button>
                    </span>
                  ))}
                </div>
              )}
              <p className="text-xs text-slate-500">Press Enter or click Add to add each nickname</p>
            </div>
            <div className="flex items-center gap-3">
              <Switch
                checked={form.is_active}
                onCheckedChange={v => setForm(f => ({ ...f, is_active: v }))}
              />
              <Label>Active employee</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={closeDialog}>Cancel</Button>
            <Button
              onClick={handleSave}
              disabled={!form.name || saveMutation.isPending}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {saveMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "Save"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}