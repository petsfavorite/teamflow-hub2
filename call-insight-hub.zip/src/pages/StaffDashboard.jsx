import { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Phone, CalendarCheck, AlertTriangle, Loader2, ArrowLeft, UserCheck } from "lucide-react";
import StatCard from "@/components/dashboard/StatCard";
import CallCard from "@/components/dashboard/CallCard";
import CallDetailPanel from "@/components/dashboard/CallDetailPanel";
import CallerTypeChart from "@/components/dashboard/CallerTypeChart";
import DateRangePicker, { getDateRange } from "@/components/dashboard/DateRangePicker";

export default function StaffDashboard() {
  const params = new URLSearchParams(window.location.search);
  const staffName = params.get("name") || "";

  const [selectedCall, setSelectedCall] = useState(null);
  const [datePreset, setDatePreset] = useState("last30");
  const [customStart, setCustomStart] = useState(null);
  const [customEnd, setCustomEnd] = useState(null);

  const { data: user } = useQuery({
    queryKey: ["me"],
    queryFn: () => base44.auth.me()
  });

  const isAdmin = user?.role === "admin";

  const { data: calls = [], isLoading, refetch } = useQuery({
    queryKey: ["calls"],
    queryFn: () => base44.entities.CallRecord.list("-call_date", 500),
  });

  const staffCalls = useMemo(() =>
    calls.filter(c => c.answered_by === staffName),
    [calls, staffName]
  );

  const { start: dateStart, end: dateEnd } = useMemo(
    () => getDateRange(datePreset, customStart, customEnd),
    [datePreset, customStart, customEnd]
  );

  const filteredCalls = useMemo(() => {
    return staffCalls.filter(call => {
      const d = new Date(call.call_date);
      if (dateStart && d < dateStart) return false;
      if (dateEnd && d > dateEnd) return false;
      return true;
    });
  }, [staffCalls, dateStart, dateEnd]);

  const stats = useMemo(() => {
    const total = filteredCalls.length;
    const booked = filteredCalls.filter(c => c.was_booked).length;
    const bookable = filteredCalls.filter(c => c.bookable === "yes").length;
    const missed = filteredCalls.filter(c => c.bookable === "yes" && !c.was_booked).length;
    const bookingRate = bookable > 0 ? Math.round((booked / bookable) * 100) : 0;
    return { total, booked, bookable, missed, bookingRate };
  }, [filteredCalls]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <div className="bg-white border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
          <Link
            to={createPageUrl("Dashboard")}
            className="inline-flex items-center gap-1.5 text-sm text-slate-500 hover:text-slate-800 mb-4 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" /> Back to Dashboard
          </Link>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 font-bold text-lg">
              {staffName.split(" ").map(n => n[0]).join("").slice(0, 2).toUpperCase()}
            </div>
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
                {staffName}
                <UserCheck className="w-5 h-5 text-blue-500" />
              </h1>
              <p className="text-sm text-slate-500 mt-0.5">
                {filteredCalls.length} calls in selected range · {stats.booked} booked · {stats.missed} missed
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
        {/* Stat Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            label="Total Calls"
            value={stats.total}
            icon={Phone}
            accentColor="bg-blue-500"
          />
          <StatCard
            label="Booking Rate"
            value={`${stats.bookingRate}%`}
            subtitle={`${stats.booked} of ${stats.bookable} bookable`}
            icon={CalendarCheck}
            accentColor="bg-emerald-500"
          />
          <StatCard
            label="Calls Booked"
            value={stats.booked}
            icon={CalendarCheck}
            accentColor="bg-amber-500"
          />
          <StatCard
            label="Missed Bookings"
            value={stats.missed}
            subtitle="Could have booked"
            icon={AlertTriangle}
            accentColor="bg-red-500"
          />
        </div>

        {/* Chart */}
        <div className="max-w-lg">
          <CallerTypeChart calls={filteredCalls} />
        </div>

        {/* Date Range */}
        <DateRangePicker
          preset={datePreset}
          onPresetChange={setDatePreset}
          customStart={customStart}
          customEnd={customEnd}
          onCustomChange={(start, end) => { setCustomStart(start); setCustomEnd(end); }}
        />

        {/* Call Feed */}
        <div className="space-y-3">
          <h2 className="text-sm font-semibold text-slate-700">
            {filteredCalls.length} Call{filteredCalls.length !== 1 ? "s" : ""}
          </h2>
          {filteredCalls.length === 0 ? (
            <div className="bg-white rounded-xl border border-dashed border-slate-200 p-12 text-center">
              <Phone className="w-8 h-8 text-slate-300 mx-auto mb-3" />
              <p className="text-sm text-slate-500">No calls in this date range</p>
            </div>
          ) : (
            <div className="space-y-2">
              {filteredCalls.map(call => (
                <CallCard key={call.id} call={call} onClick={setSelectedCall} />
              ))}
            </div>
          )}
        </div>
      </div>

      <CallDetailPanel
        call={selectedCall}
        open={!!selectedCall}
        onClose={() => setSelectedCall(null)}
        onUpdate={refetch}
        isAdmin={isAdmin}
      />
    </div>
  );
}