import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users } from "lucide-react";
import { cn } from "@/lib/utils";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function StaffLeaderboard({ calls, teamMembers = [] }) {
  const teamNameSet = new Set(teamMembers.map(m => m.name));
  const staffStats = {};
  calls.forEach(call => {
    const key = call.team_member || call.answered_by;
    if (!key) return;
    // Skip anyone not on the official team list (if team list is loaded)
    if (teamMembers.length > 0 && !teamNameSet.has(key)) return;
    if (!staffStats[key]) {
      staffStats[key] = { total: 0, answered: 0, booked: 0, possibleBooked: 0 };
    }
    staffStats[key].total += 1;
    // Inbound answered = inbound calls that have a transcript or booking outcome (i.e. were actually answered)
    if (call.call_direction === "inbound" && call.booking_outcome && call.booking_outcome !== "appt_not_needed") {
      staffStats[key].answered += 1;
    } else if (call.call_direction === "inbound" && call.transcript_summary) {
      staffStats[key].answered += 1;
    } else if (call.call_direction === "inbound" && call.booking_outcome !== "appt_not_needed") {
      staffStats[key].answered += 1;
    }
    // Possible bookings = all calls (inbound and outbound) that were either booked or missed booking
    if (call.booking_outcome === "appt_booked" || call.booking_outcome === "appt_not_booked") {
      staffStats[key].possibleBooked += 1;
    }
    if (call.booking_outcome === "appt_booked" || call.was_booked) {
      staffStats[key].booked += 1;
    }
  });

  const sorted = Object.entries(staffStats)
    .map(([name, stats]) => ({
      name,
      ...stats,
      bookingRate: stats.possibleBooked > 0 ? Math.round((stats.booked / stats.possibleBooked) * 100) : null
    }))
    .sort((a, b) => b.total - a.total);

  if (sorted.length === 0) {
    return (
      <Card className="border-0 shadow-sm">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold text-slate-700 flex items-center gap-2">
            <Users className="w-4 h-4 text-blue-500" />
            Team Performance
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-slate-400 text-center py-4">No call data yet</p>
        </CardContent>
      </Card>
    );
  }

  const maxAnswered = Math.max(...sorted.map(s => s.answered), 1);

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-semibold text-slate-700 flex items-center gap-2">
          <Users className="w-4 h-4 text-blue-500" />
          Team Performance
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {sorted.map((staff, i) => (
          <div key={staff.name} className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className={cn(
                  "w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold",
                  i === 0 ? "bg-blue-100 text-blue-700" :
                  i === 1 ? "bg-slate-100 text-slate-600" :
                  "bg-slate-50 text-slate-400"
                )}>
                  {i + 1}
                </div>
                <Link
                  to={createPageUrl(`StaffDashboard?name=${encodeURIComponent(staff.name)}`)}
                  className="text-sm font-medium text-slate-800 hover:text-blue-600 hover:underline transition-colors"
                >
                  {staff.name}
                </Link>
              </div>
              <span className="text-xs text-slate-500">{staff.answered} inbound answered</span>
            </div>
            {/* Blue bar: inbound calls answered */}
            <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-blue-500 rounded-full transition-all duration-500"
                style={{ width: `${(staff.answered / maxAnswered) * 100}%` }}
              />
            </div>
            
            {staff.possibleBooked > 0 && (
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-500">Appts Booked</span>
                <span className={cn(
                  "text-xs font-semibold",
                  staff.bookingRate >= 70 ? "text-emerald-600" :
                  staff.bookingRate >= 40 ? "text-amber-600" :
                  "text-red-500"
                )}>
                  {staff.bookingRate}% ({staff.booked}/{staff.possibleBooked})
                </span>
              </div>
            )}
            {/* Green bar: booked out of possible bookings */}
            {staff.possibleBooked > 0 && (
              <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-500 rounded-full transition-all duration-500"
                  style={{ width: `${(staff.booked / staff.possibleBooked) * 100}%` }}
                />
              </div>
            )}
          </div>
        ))}
      </CardContent>
    </Card>
  );
}