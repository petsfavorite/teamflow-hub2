import { Badge } from "@/components/ui/badge";
import { CalendarCheck, CalendarX, CalendarMinus, HelpCircle } from "lucide-react";
import { cn } from "@/lib/utils";

export default function BookingStatus({ bookable, wasBooked, bookedDate, bookingOutcome }) {
  if (bookingOutcome === "appt_not_booked") {
    return (
      <Badge variant="outline" className="bg-red-50 text-red-600 border-red-200 hover:bg-red-50 gap-1 text-xs">
        <CalendarX className="w-3 h-3" />
        Missed Booking
      </Badge>
    );
  }

  const isBooked = wasBooked || bookingOutcome === "appt_booked";
  
  if (isBooked && bookedDate) {
    const formatted = new Date(bookedDate).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric"
    });
    return (
      <div className="flex flex-col gap-1">
        <Badge variant="outline" className="bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-50 gap-1 text-xs w-fit">
          <CalendarCheck className="w-3 h-3" />
          Booked
        </Badge>
        <span className="text-xs text-slate-500 pl-0.5">{formatted}</span>
      </div>
    );
  }

  if (isBooked) {
    return (
      <Badge variant="outline" className="bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-50 gap-1 text-xs">
        <CalendarCheck className="w-3 h-3" />
        Booked
      </Badge>
    );
  }

  if (bookable === "yes") {
    return (
      <Badge variant="outline" className="bg-slate-50 text-slate-500 border-slate-200 hover:bg-slate-50 gap-1 text-xs">
        <CalendarMinus className="w-3 h-3" />
        Not Bookable
      </Badge>
    );
  }

  if (bookable === "no") {
    return (
      <Badge variant="outline" className="bg-slate-50 text-slate-500 border-slate-200 hover:bg-slate-50 gap-1 text-xs">
        <Minus className="w-3 h-3" />
        Not Bookable
      </Badge>
    );
  }

  return (
    <Badge variant="outline" className="bg-slate-50 text-slate-500 border-slate-200 hover:bg-slate-50 gap-1 text-xs">
      <CalendarMinus className="w-3 h-3" />
      Not Bookable
    </Badge>
  );
}

function Minus(props) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <path d="M5 12h14"/>
    </svg>
  );
}